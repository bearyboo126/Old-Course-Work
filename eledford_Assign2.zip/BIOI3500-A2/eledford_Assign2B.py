#!/usr/bin/python3
# Name: Erin Ledford
# Class: BIOI3500, Spring 2021
# Assignment #: Assignment 2B
# Due date: February 5th, 2021
#
# Honor Pledge: On my honor as a student of the University of Nebraska at
#               Omaha, I have neither given nor recieved unauthorized help on
#               this programming assignment.
#
# NAME: Erin Ledford
# EMAIL: eledford@unomaha.edu
#
# Partners: NONE
#
# This program displays the amino acid sequence for a fragment of DNA entered
# as a command line argument, it gives the reading frame specified by the
# user as well.

import sys
import getopt

class eledford_Assign2B:
    def main():

        # Read in the command-line arguments into the opts list.
        try:
            opts, args = getopt.getopt(sys.argv[1:], "f:s:")
        
        except getopt.GetoptError as err:
            # Redirect STDERR to STDOUT (insures screen display)
            sys.stdout = sys.stderr

            # Print help information
            print(str(err))

            # Print usage information; usage() is the name of a
            # function (declared elsewhere) that displays
            # information (just a series of print statements).
            usage()

            # Exit the program
            sys.exit(2)

        # The codon table is a dictionary of codons to compare against
        # the DNA sequence given by the user
        codonTable = { 'TTT':'F', 'TTC':'F', 'TTA':'L', 'TTG':'L',
                'TCT':'S', 'TCC':'S', 'TCA':'S', 'TCG':'S',
                'TAT':'Y', 'TAC':'Y', 'TAA':'*', 'TAG':'*',
                'TGT':'C', 'TGC':'C', 'TGA':'*', 'TGG':'W',
                'CTT':'L', 'CTC':'L', 'CTA':'L', 'CTG':'L',
                'CCT':'P', 'CCC':'P', 'CCA':'P', 'CCG':'P',
                'CAT':'H', 'CAC':'H', 'CAA':'Q', 'CAG':'Q',
                'CGT':'R', 'CGC':'R', 'CGA':'R', 'CGG':'R',
                'ATT':'I', 'ATC':'I', 'ATA':'I', 'ATG':'M',
                'ACT':'T', 'ACC':'T', 'ACA':'T', 'ACG':'T',
                'AAT':'N', 'AAC':'N', 'AAA':'K', 'AAG':'K',
                'AGT':'S', 'AGC':'S', 'AGA':'R', 'AGG':'R',
                'GTT':'V', 'GTC':'V', 'GTA':'V', 'GTG':'V',
                'GCT':'A', 'GCC':'A', 'GCA':'A', 'GCG':'A',
                'GAT':'D', 'GAC':'D', 'GAA':'E', 'GAG':'E',
                'GGT':'G', 'GGC':'G', 'GGA':'G', 'GGG':'G'}

        # The reading frame is used to figure out where to start on
        # the DNA sequence
        readingFrame = 0

        # An empty list for a DNA sequence given by the user
        dna = []

        # An empty list for a complmentary sequence of the DNA
        # sequence given by the user
        complement = []

        # To decide where to begin when counting the DNA
        n = 0

        # An empty list for converting the DNA sequence into a protein
        # sequence
        proteinSequence = []

        # Process the opt and arg lists displaying the arg for
        # each option
        for (opt, arg) in opts:
            if(opt == '-f'):
                # If the argument is 0 or greater than 3, set it to 1
                # so there is no out of bounds reading frame
                if (int(arg) == 0 or int(arg) > 3):
                    readingFrame = 1
                # If the argument is less than -3, set it to -1
                # so there is no out of bounds reading frame
                elif (int(arg) < -3):
                    readingFrame = -1
                # If it does not fall under the two above if statements
                # it is a valid reading frame
                else:
                    readingFrame = int(arg)

            if(opt == '-s'):
                # Sets the previously empty dna variable to the argument
                dna = arg

                # Makes sure the arg is in uppercase
                dna = dna.upper()

                # Checks the dna to make sure it has valid characters
                for i in dna:
                    if (str(i) != 'A' and str(i) != 'T' 
                            and  str(i) != 'C' and str(i) != 'G'):
                        dna = dna.replace(i, "X")

                # Creates the complement of the DNA sequence given
                # to use for negative reading frames
                complement = dna.replace("A", "t")
                complement = dna.replace("T", "a")
                complement = dna.replace("G", "c")
                complement = dna.replace("C", "g")
                complement = complement.upper()
        
        # If the reading frame is between 1 and 3 it uses the dna variable
        # to create the protein sequence
        if(readingFrame == 1 or readingFrame == 2 or readingFrame == 3):
            if readingFrame == 1:
                n = 0
            if readingFrame == 2:
                n = 1
            if readingFrame == 3:
                n = 2

            # Transcribes the dna into a protein sequence and changes it into
            # a string
            proteinSequence = [codonTable.get(dna[n:n+3], 'X') 
                    for n in range(0, len(dna), 3)]
            proteinSequence = ''.join(proteinSequence)

            # Prints the final result
            print(proteinSequence)

        # If the reading frame is from -1 to -3 it uses the complement
        # to create the protein sequence
        if(readingFrame == -1 or readingFrame == -2 or readingFrame == -3):
            if readingFrame == -1:
                n = 0
            if readingFrame == -2:
                n = 1
            if readingFrame == -3:
                n = 2
            
            # Transcribes the complementary strand into a protein sequence
            # and changes the list into a string
            proteinSequence = [codonTable.get(complement[n:n+3], 'X') 
                    for n in range(0, len(complement), 3)]
            proteinSequence = ''.join(proteinSequence)

            # Prints the final result
            print(proteinSequence)




    if __name__ == '__main__':
        main()
