#!/usr/bin/python3
# Name: Erin Ledford
# Class: BIOI 3500, Spring 2021
# Assignment #: Assignment 2
# Due Date: February 5th, 2021
#
# Honor Pledge: On my honor as a student of the University of Nebraska at
#               Omaha, I have neither given nor recieved unauthorized help on
#               this programming assignment.
#
# NAME: Erin Ledford
# EMAIL: eledford@unomaha.edu
#
# Partners: NONE
#
# This program generates a random coding DNA between 25 to 50 codons
# and allows the user to change how the DNA is generated via command line
# arguements.

import random
import getopt
import sys

class eledford_Assign2A: 

    def main():

        # Read in the command-line arguments into the opts list
        try:
            opts, args = getopt.getopt(sys.argv[1:], "c:s:l")

        except getopt.GetoptError as err:
            # Redirect STDERR to STDOUT (insures screen display) 
            sys.stdout = sys.stderr

            # Print help information
            print(str(err))

            # Print usage information; usage() is the name of a
            # function (declared elsewhere) that displays usage
            # information (just a series of print statements).
            usage()

            # Exit the program
            sys.exit(2)

        # The possible DNA bases for the randomly generated sequence
        dnaBases = list('ATGC')

        # The random amount of bases in the DNA sequence
        x = random.randint(25,50)

        # X is subtracted by 6 to get ATG and the stop codon
        # and have the same sequence length
        x = x - 6

        # Sets lowerIt to false, so that it may be used later
        lowerIt = False

        # A list of stopCodons
        stopCodonList = ['TAG', 'TAA', 'TGA']

        # A stopCodon is randomly selected
        stopCodon = random.choice(stopCodonList)

        # The stop codon is changed into a string
        stopCodon = ''.join(stopCodon)

        # Process the opt and arg lists displaying the argument of
        # each option
        for (opt, arg) in opts:

            # If -c is used, the sequence length is changed from the original
            # randomly chosen one
            if (opt == '-c'):
                x = int(arg)
                x = x - 6

            # If -s is used, the stopCodon is changed to the argument if the
            # argument is valid
            if (opt == '-s'):
                if (str(arg) == 'TAG' or str(arg) == 'TAA' 
                        or str(arg) == 'TGA'):
                    stopCodon = arg
            
            # If -l is used, lowerIt is set to true
            if (opt == '-l'):
                lowerIt = True

        # A dna sequence is randomly generated using x and then changed into
        # a string
        dna = [random.choice(dnaBases) for i in range(x)]
        dna = ''.join(dna)

        # A replacement is made based on the third base that will make
        # sure that all internal stop codons are replaced with codons
        randoReplace = random.choice('TC')
        dna = dna.replace("TAG","TA"+ randoReplace)
        dna = dna.replace("TAA", "TA"+ randoReplace)
        dna = dna.replace("TGA","TG" + randoReplace)

        # The randomly generated DNA is put together
        dna = 'ATG' + dna[0:] + stopCodon

        # If lowerIt is changed to true, it changes the DNA to lowercase
        if lowerIt == True:
            dna = dna.lower()

        # Prints the randonly generated DNA strand
        print(str(dna))
            


    if __name__ == '__main__':
        main()
