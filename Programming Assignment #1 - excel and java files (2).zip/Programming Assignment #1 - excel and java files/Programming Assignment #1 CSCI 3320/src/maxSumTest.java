/***************************************************
 * Program Title: maxSumTest *
 * Author: Erin Ledford *
 * Class: CSCI3320, Summer 2020 *
 * Assignment #1 *
 ****************************************************/ 

import java.util.Scanner;
import java.util.Random;

/***************************************************
* FUNCTION xxyyzz : maxSumTest*
* the purpose of this function: to create and run algorithms 2, 3, and 4 for the maximum subsequence problem. *
* INPUT PARAMETERS : *
* None *
* OUTPUT : *
* The algorithms run times and their maximum subsequences. *
 ****************************************************/ 
public final class maxSumTest
{
	static private int s = 0;
	static private int e= -1;
	
/***************************************************
* FUNCTION xxyyzz : maxSubSum2*
* the purpose of this function: To figure out the maximum subsequence in O(n^2) time complexity. *
* INPUT PARAMETERS : *
* a - an array of numbers that are used to find the maximum subsequence. *
* OUTPUT : *
* the maximum subsequence in O(N ^2) time complexity. *
****************************************************/ 
	public static int maxSubSum2(int [] a)
	{
		int maxSum = 0;
		int thisSum = 0;

		for(int i = 0, j = 0; j < a.length; j++)
		{
			thisSum += a[ j ];

			if(thisSum > maxSum)
			{
				maxSum = thisSum;
				s = i;
				e = a.length - 1;
			}
			else if(thisSum < 0)
			{
				i = j + 1;
				thisSum = 0;
			}
		}

		return maxSum;
	}
	
	/***************************************************
	 * FUNCTION xxyyzz : maxSumRecursive*
	 * the purpose of this function: to find the maximum subsequence in O(N log N) time complexity. *
	 * INPUT PARAMETERS :  *
	 * a - the array of number from which the maximum subsequence is found, 
	 * left - the leftmost border of the array,
	 *  right - right border of the array. *
	 * OUTPUT : *
	 * the  three border sums to give to a helper function to figure out the actual max subsequence.*
	 ****************************************************/ 
	private static int maxSumRecursive(int [] a, int left, int right)
	{
		int maxLeftBorderSum = 0;
		int maxRightBorderSum = 0;
		int leftBorderSum = 0;
		int rightBorderSum = 0;
		
		int center = (left + right) / 2;

		if(left == right)
		{
			return a[left] > 0 ? a[left] : 0;
		}

		int maxLeftSum = maxSumRecursive(a, left, center);
		int maxRightSum = maxSumRecursive(a, center + 1, right);

		for(int i = center; i >= left; i--)
		{
			leftBorderSum += a[i];
			if(leftBorderSum > maxLeftBorderSum)
			{
				maxLeftBorderSum = leftBorderSum;
			}
		}

		for(int i = center + 1; i <= right; i++)
		{
			rightBorderSum += a[i];
			if(rightBorderSum > maxRightBorderSum)
			{
				maxRightBorderSum = rightBorderSum;
			}
		}

		return maximumOf3(maxLeftSum, maxRightSum,
				maxLeftBorderSum + maxRightBorderSum);
	}
	/***************************************************
	 * FUNCTION xxyyzz : max3*
	 * the purpose of this function: To figure out the maximum subsequence. A helper method. *
	 * INPUT PARAMETERS : *
	 * a - the maximum left sum, b - the maximum right sum, c - the maximum left sum and right sum added together. *
	 * OUTPUT : *
	 * which of a, b, or c is the greatest sum.*
	 ****************************************************/ 
	private static int maximumOf3(int a, int b, int c)
	{
		return a > b ? a > c ? a : c : b > c ? b : c;
	}
	/***************************************************
	* FUNCTION xxyyzz : maxSubSum4*
	* the purpose of this function: to find the maximum subsequence in O(N) time complexity. *
	* INPUT PARAMETERS : *
	* inputArr - the array that is input into the method to find its maximum subsequence. *
	* OUTPUT : *
	* the maximum subsequence in O(N) time complexity. *
	 ****************************************************/ 
	public static int maxSubSum4(int[] inputArr) 
	{  
		int maxSum = 0;
		int thisSum = 0;
		 
		for (int j = 0; j < inputArr.length; j++) 
		{
			thisSum += inputArr[j];
			if (thisSum > maxSum)
			{
				maxSum = thisSum;
			}
			else if (thisSum < 0)
			{
				thisSum = 0;
			}
		}	
		 
		return maxSum;
	}
		 
	/***************************************************
	 * FUNCTION xxyyzz : main*
	 * the purpose of this function: to see how long it takes all algorithms to run and then prints the answer. *
	 * INPUT PARAMETERS : *
	 * None *
	 * OUTPUT : *
	 * the time it takes an algorithm to run and its maximum subsequence. *
	 ****************************************************/ 
	public static void main(String [] args)
	{
		
		
		Scanner scan = new Scanner(System.in);
		
		int min = -9999;
		int max = 9999;
		int range = max - min + 1;
		int maxSum;
		
		System.out.print("Please enter the size of the problem (N) : \n");
		int N = scan.nextInt();
		
		int theRandArray[] = new int[N];
		Random rand = new Random();

		for(int i = 0; i < theRandArray.length; i++)
		{
			theRandArray[i] = rand.nextInt(range) + min;
		}
		
		
		if (N < 50) 
		{
			for(int i = 0; i < theRandArray.length; i++)
			{
				
				System.out.print(theRandArray[i] + " ");
			}
			
			
			ExecutionTimer time = new ExecutionTimer();
			
			time.start();
			maxSum = maxSubSum2(theRandArray);
			time.end();
			System.out.println("\n\nAlgorithm 2:");
			System.out.println( "MaxSum: " + maxSum + ", S_Index: " + s 
					+ ", E_Index: " + e);
			System.out.printf("Execution Time: ");
			System.out.print(time.duration());
			System.out.print(" nanoseconds\n\n");
			time.reset();
			
			time.start();
			maxSum = maxSumRecursive(theRandArray, 0, theRandArray.length -1);
			time.end();
			System.out.println("Algorithm 3:");
			System.out.println( "MaxSum: " + maxSum + ", S_Index: " + s 
					+ ", E_Index: " + e);
			System.out.printf("Execution Time: ");
			System.out.print(time.duration());
			System.out.print(" nanoseconds\n\n");
			time.reset();
			
			time.start();
			maxSum = maxSubSum4(theRandArray);
			time.end();
			System.out.println("Algorithm 4: " );
			System.out.println( "MaxSum: " + maxSum + ", S_Index: " + s 
					+ ", E_Index: " + e);
			System.out.printf("Execution Time: ");
			System.out.print(time.duration());
			System.out.print(" nanoseconds\n\n");
			time.reset();
		}
		else
		{
			ExecutionTimer time = new ExecutionTimer();
			
			time.start();
			maxSum = maxSubSum2(theRandArray);
			time.end();
			System.out.println("Algorithm 2:");
			System.out.println( "MaxSum: " + maxSum + ", S_Index: " + s 
					+ ", E_Index: " + e);
			System.out.printf("Execution Time: ");
			System.out.print(time.duration());
			System.out.print(" nanoseconds\n\n");
			time.reset();
			
			time.start();
			maxSum = maxSumRecursive(theRandArray, 0, theRandArray.length -1);
			time.end();
			System.out.println("Algorithm 3:");
			System.out.println( "MaxSum: " + maxSum + ", S_Index: " + s 
					+ ", E_Index: " + e);
			System.out.printf("Execution Time: ");
			System.out.print(time.duration());
			System.out.print(" nanoseconds\n\n");
			time.reset();
			
			time.start();
			maxSum = maxSubSum4(theRandArray);
			time.end();
			System.out.println("Algorithm 4: " );
			System.out.println( "MaxSum: " + maxSum + ", S_Index: " + s 
					+ ", E_Index: " + e);
			System.out.printf("Execution Time: ");
			System.out.print(time.duration());
			System.out.print(" nanoseconds\n\n");
			time.reset();
			
		}
	
	}
	
}
