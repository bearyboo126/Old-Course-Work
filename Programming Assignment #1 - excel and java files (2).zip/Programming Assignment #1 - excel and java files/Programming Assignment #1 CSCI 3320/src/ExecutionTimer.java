 /***************************************************
 * Program Title: Execution Timer *
 * Author: Erin Ledford *
 * Class: CSCI3320, Summer 2020 *
 * Assignment #1 *
 ****************************************************/ 

/***************************************************
* FUNCTION xxyyzz : Execution Timer*
* the purpose of this function: to time how long it takes an algorithm to run. *
* INPUT PARAMETERS : *
* None *
* OUTPUT : *
* the time it takes an algorithm to run. *
 ****************************************************/ 
public class ExecutionTimer 
{
	/**
	 * The start time of the sort.
	 */
	private long start;
	
	/**
	 * The end time of the sort.
	 */
	private long end;
	
	
	/***************************************************
	* FUNCTION xxyyzz : Execution Timer *
	* the purpose of this function: to reset the the start and end when called. *
	* INPUT PARAMETERS : *
	* the reset method below this one*
	* OUTPUT : *
	* resets the output to zero. *
	 ****************************************************/ 
	public ExecutionTimer()
	{
		reset();
	}
	
	/***************************************************
	* FUNCTION xxyyzz : start *
	* To start the system nano time. *
	* INPUT PARAMETERS : *
	* start - the start time of the sort. *
	* OUTPUT : *
	* the start time of the sort. *
	 ****************************************************/ 
	public void start()
	{
		start = System.nanoTime();
	}
	
	/***************************************************
	* FUNCTION xxyyzz : end *
	* to give the end time of the sort. *
	* INPUT PARAMETERS : *
	* end- the end time of the sort. *
	* OUTPUT : *
	* end - the end time of the sort. *
	 ****************************************************/ 
	public void end()
	{
		end = System.nanoTime();
	}
	
	/***************************************************
	* FUNCTION xxyyzz : duration *
	* the purpose of this function: to give the duration of the sort by subtracting start time from the end time. *
	* INPUT PARAMETERS : *
	* start - the start time of the algorithm, end - the end time of the algorithm. *
	* OUTPUT : *
	* returns the duration of the sort by subtracting start time from the end time. *
	 ****************************************************/ 
	public long duration()
	{
		return (end-start);
	}
	
	/***************************************************
	* FUNCTION xxyyzz : reset *
	* the purpose of this function: it resets the start and end times of the algorithm. *
	* INPUT PARAMETERS : *
	* start - the start time for the algorithm, end - the end time of the algorithm. *
	* OUTPUT : *
	* changes start and end to zero, called in the execution timer method. *
	 ****************************************************/ 
	public void reset()
	{
		start = 0;
		end = 0;
	}
	
	/***************************************************
	* FUNCTION xxyyzz : print *
	* the purpose of this function: prints the duration *
	* INPUT PARAMETERS : *
	* duration - the time it takes the algorithm to run. *
	* OUTPUT : *
	* prints out the duration of the algorithm *
	 ****************************************************/ 
	public void print()
	{
		System.out.print(duration() + ", ");
	}
}
