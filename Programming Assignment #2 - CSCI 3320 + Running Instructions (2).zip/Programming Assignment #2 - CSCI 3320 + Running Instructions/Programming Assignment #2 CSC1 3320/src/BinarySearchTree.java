 /***************************************************
 * Program Title: BinarySearchTree *
 * Author: Erin Ledford *
 * Class: CSCI3320, Summer 2020 *
 * Assignment #2 *
 ****************************************************/ 

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.LinkedList;
import java.util.Queue;


// BinarySearchTree class
//
// CONSTRUCTION: with no initializer
//
// ******************PUBLIC OPERATIONS*********************
// void insert( x )       --> Insert x
// void remove( x )       --> Remove x
// boolean contains( x )  --> Return true if x is present
// Comparable findMin( )  --> Return smallest item
// Comparable findMax( )  --> Return largest item
// boolean isEmpty( )     --> Return true if empty; else false
// void makeEmpty( )      --> Remove all items
// void printTree( )      --> Print tree in sorted order
// ******************ERRORS********************************
// Throws UnderflowException as appropriate

/**
 * Implements an unbalanced binary search tree.
 * Note that all "matching" is based on the compareTo method.
 * @author Mark Allen Weiss
 */
public class BinarySearchTree<AnyType extends Comparable<? super AnyType>>
{
    /**
     * Construct the tree.
     */
    public BinarySearchTree( )
    {
        root = null;
    }

    /**
     * Insert into the tree; duplicates are ignored.
     * @param x the item to insert.
     */
    public void insert( AnyType x )
    {
        root = insert( x, root );
    }

    /**
     * Remove from the tree. Nothing is done if x is not found.
     * @param x the item to remove.
     */
    public void remove( AnyType x )
    {
        root = remove( x, root );
    }

    /**
     * Find the smallest item in the tree.
     * @return smallest item or null if empty.
     */
    public AnyType findMin( )
    {
        if( isEmpty( ) )
            throw new RuntimeException( );
       return findMin( root ).element;
    }

    /**
     * Find the largest item in the tree.
     * @return the largest item of null if empty.
     */
    public AnyType findMax( )
    {
        if( isEmpty( ) )
           throw new RuntimeException( );
        return findMax( root ).element;
   }

    /**
     * Find an item in the tree.
     * @param x the item to search for.
     * @return true if not found.
     */
    public boolean contains( AnyType x )
    {
        return contains( x, root );
    }

    /**
     * Make the tree logically empty.
     */
    public void makeEmpty( )
    {
        root = null;
    }

    /**
     * Test if the tree is logically empty.
     * @return true if empty, false otherwise.
     */
    public boolean isEmpty( )
    {
        return root == null;
    }

    /**
     * Print the tree contents in sorted order.
     */
    public void printTree( )
    {
        if( isEmpty( ) )
            System.out.println( "Empty tree" );
        else
            printTree( root );
    }

    /**
     * Internal method to insert into a subtree.
     * @param x the item to insert.
     * @param t the node that roots the subtree.
     * @return the new root of the subtree.
     */
    private BinaryNode<AnyType> insert( AnyType x, BinaryNode<AnyType> t )
    {
        if( t == null )
            return new BinaryNode<>( x, null, null );
        
        int compareResult = x.compareTo( t.element );
            
        if( compareResult < 0 )
            t.left = insert( x, t.left );
        else if( compareResult > 0 )
            t.right = insert( x, t.right );
        else
            ;  // Duplicate; do nothing
        return t;
    }

    /**
     * Internal method to remove from a subtree.
     * @param x the item to remove.
     * @param t the node that roots the subtree.
     * @return the new root of the subtree.
     */
    private BinaryNode<AnyType> remove( AnyType x, BinaryNode<AnyType> t )
    {
        if( t == null )
            return t;   // Item not found; do nothing
            
        int compareResult = x.compareTo( t.element );
            
        if( compareResult < 0 )
            t.left = remove( x, t.left );
        else if( compareResult > 0 )
            t.right = remove( x, t.right );
        else if( t.left != null && t.right != null ) // Two children
        {
            t.element = findMin( t.right ).element;
            t.right = remove( t.element, t.right );
        }
        else
            t = ( t.left != null ) ? t.left : t.right;
        return t;
    }

    /**
     * Internal method to find the smallest item in a subtree.
     * @param t the node that roots the subtree.
     * @return node containing the smallest item.
     */
    private BinaryNode<AnyType> findMin( BinaryNode<AnyType> t )
    {
        if( t == null )
            return null;
        else if( t.left == null )
            return t;
        return findMin( t.left );
    }

    /**
     * Internal method to find the largest item in a subtree.
     * @param t the node that roots the subtree.
     * @return node containing the largest item.
     */
    private BinaryNode<AnyType> findMax( BinaryNode<AnyType> t )
    {
        if( t != null )
            while( t.right != null )
                t = t.right;

        return t;
    }

    /**
     * Internal method to find an item in a subtree.
     * @param x is item to search for.
     * @param t the node that roots the subtree.
     * @return node containing the matched item.
     */
    private boolean contains( AnyType x, BinaryNode<AnyType> t )
    {
        if( t == null )
            return false;
            
        int compareResult = x.compareTo( t.element );
            
        if( compareResult < 0 )
            return contains( x, t.left );
        else if( compareResult > 0 )
            return contains( x, t.right );
        else
            return true;    // Match
    }

    /**
     * Internal method to print a subtree in sorted order.
     * @param t the node that roots the subtree.
     */
    private void printTree( BinaryNode<AnyType> t )
    {
        if( t != null )
        {
            printTree( t.right );
            System.out.println( t.element + " " );
            printTree( t.left );
        }
    }

    /**
     * Internal method to compute height of a subtree.
     * @param t the node that roots the subtree.
     */
    private int height( BinaryNode<AnyType> t )
    {
        if( t == null )
            return -1;
        else
            return 1 + Math.max( height( t.left ), height( t.right ) );    
    }
    
    // Basic node stored in unbalanced binary search trees
    private static class BinaryNode<AnyType>
    {
            // Constructors
        BinaryNode( AnyType theElement )
        {
            this( theElement, null, null );
        }

        BinaryNode( AnyType theElement, BinaryNode<AnyType> lt, BinaryNode<AnyType> rt )
        {
            element  = theElement;
            left     = lt;
            right    = rt;
        }

        AnyType element;            // The data in the node
        BinaryNode<AnyType> left;   // Left child
        BinaryNode<AnyType> right;  // Right child
    }
    
    /***************************************************
    * FUNCTION xxyyzz : numLeaves *
    * the purpose of this function: to find the number of leaves in a binary tree *
    * INPUT PARAMETERS : *
    * BinaryNode<AnyType> t - the tree nodes *
    * OUTPUT : *
    * returns the number of leaves in a binary search tree*
     ****************************************************/ 
    public int numLeaves (BinaryNode<AnyType> t)
    {

    	
    	if (t == null)
    	{
    		return 0;
    	}
    	
    	if (t.left == null && t.right == null)
    	{
    		return 1;
    	}
    	else
    	{
    		return numLeaves(t.left) + numLeaves(t.right);
    	}
    	
    }
    
    /***************************************************
    * FUNCTION xxyyzz : numOneChildNodes *
    * to find the number of child nodes in a tree. *
    * INPUT PARAMETERS : *
    * BinaryNode<AnyType> t - the tree nodes  *
    * OUTPUT : *
    * the number of tree nodes in a binary search tree. *
     ****************************************************/ 
    public int numOneChildNodes (BinaryNode<AnyType> t)
    {
    	int nums = 0;
    	
    	if (t == null)
    	{
    		return 0;
    	}
    	
    	if (oneNullNode(t.left, t.right)) //helper function called
    	{
    		nums = 1;
    	}
    	
    	return numOneChildNodes(t.left) + numOneChildNodes(t.right) + nums;
    }
    
    /***************************************************
    * FUNCTION xxyyzz : oneNullNode *
    * the purpose of this function: to find if one node (left or right) is null, thereby only having one child node *
    * INPUT PARAMETERS : *
    * BinaryNode<AnyType> firstNode - the first child node, 
    * BinaryNode<AnyType> secondNode - the second child node*
    * OUTPUT : *
    * returns true if there is only one child node, 
    * returns false if there are two *
     ****************************************************/ 
    private boolean oneNullNode (BinaryNode<AnyType> firstNode, BinaryNode<AnyType> secondNode)
    {
    	if (firstNode == null && secondNode != null)
    	{
    		return true;
    	}
    	else if (firstNode != null && secondNode == null)
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
    
    /***************************************************
    * FUNCTION xxyyzz : numTwoChildrenNodes *
    * the purpose of this function: to find out if any nodes have two children nodes *
    * INPUT PARAMETERS : *
    * BinaryNode<AnyType> t - the nodes in the tree *
    * OUTPUT : *
    * returns the number of nodes with child nodes *
     ****************************************************/ 
    public int numTwoChildrenNodes (BinaryNode<AnyType> t)
    {
    	int doesItHaveTwo = 0;
    	
    	if (t == null)
    	{
    		return doesItHaveTwo;
    	}
    	
    	if (t.right != null && t.left != null)
    	{
    		doesItHaveTwo = 1;
    	}
    	
    	return doesItHaveTwo + numTwoChildrenNodes(t.left) 
    	+ numTwoChildrenNodes(t.right);
    }
    
    /***************************************************
    * FUNCTION xxyyzz : (function name) *
    * the purpose of this function *
    * INPUT PARAMETERS : *
    * a list of all parameters and their meaning *
    * OUTPUT : *
    * the description about returning value *
     ****************************************************/ 
    public void levelOrder (BinaryNode<AnyType> t)
    {
    	Queue theQueue = new LinkedList();
    	theQueue.add(t);
    	
    	while (!theQueue.isEmpty())
    	{
    		BinaryNode itsAllTemporary = (BinaryNode) theQueue.poll();
    		System.out.printf("%d ", itsAllTemporary.element);
    		
    		if (itsAllTemporary.left != null)
    		{
    			theQueue.add(itsAllTemporary.left);
    		}
    		
    		if (itsAllTemporary.right != null)
    		{
    			theQueue.add(itsAllTemporary.right);
    		}
    	}
    	
    }
    
    /***************************************************
    * FUNCTION xxyyzz : printBetween *
    * the purpose of this function: to print the numbers between two values in the tree *
    * INPUT PARAMETERS : *
    * BinaryNode<Integer> t - the nodes in the tree, 
    * Integer k1 - the first value, 
    * Integer k2 - the second value*
    * OUTPUT : *
    * prints the nodes between k1 and k2 *
     ****************************************************/ 
    public void printBetween (BinaryNode<Integer> t, Integer k1, Integer k2)
    {
    	if (t == null)
    	{
    		return;
    	}
    	
    	if (k1 < t.element)
    	{
    		printBetween(t.left, k1, k2);
    	}
    	
    	if (k1 <= t.element && k2 >= t.element)
    	{
    		System.out.print(t.element + " ");
    	}
    	
    	if (k2 > t.element)
    	{
    		printBetween (t.right, k1, k2);
    	}
    }
    
      /** The tree root. */
    private BinaryNode<AnyType> root;


    /***************************************************
    * FUNCTION xxyyzz : main *
    * the purpose of this function: to test the code above *
    * INPUT PARAMETERS : *
    * Integers *
    * OUTPUT : *
    * prints the tree in descending, prints the number of leaves, 
    * prints the numbers of nodes in t that contain one child,
    * prints the number of nodes in t that contain two children nodes, 
    * prints the level order of traversal, 
    * prints all the elements in the tree between k1 and k2 *
     ****************************************************/ 
    public static void main( String [ ] args ) throws IOException
    {
        BinarySearchTree<Integer> t = new BinarySearchTree<>( );
        
        BufferedReader buffering = 
        		new BufferedReader(new InputStreamReader(System.in));
        
        int option;
        
        do
        {
        	System.out.println("Enter choice [1-8] from menu below:");
        	System.out.println("1) Construct a Tree");
        	System.out.println("2) Print tree in descending order");
        	System.out.println("3) Print number of leaves in the tree");
        	System.out.println("4) Print the number of nodes in T that contain only one child");
        	System.out.println("5) Print the number of nodes in T "
        			+ "that contain only two children");
        	System.out.println("6) Print the level order of traversal of the tree");
        	System.out.println("7) Print all the elements in the tree between k1 and k2");
        	System.out.println("8) Exit program");
        	
        	option = Integer.parseInt(buffering.readLine());
        	
        	if (option == 1)
        	{
        		System.out.println("How many numeric values do you want to enter? ");
        		
        		int amount = Integer.parseInt(buffering.readLine());
        		
        		System.out.println("Enter initial elements: ");
        		
        		for (int i = 1; i <= amount; i++)
        		{
        			System.out.println("Please input a single number and press enter:");
        			t.insert(Integer.parseInt(buffering.readLine()));
        		}
        		
        		
        	}
        	
        	if (option == 2)
        	{
        		System.out.println("Print in descending order: ");
        		
        		t.printTree();
        		
        		System.out.println();
        		
        		
        	}
        	
        	if (option == 3)
        	{
        		int leaves = t.numLeaves(t.root);
        		
        		System.out.println("The number of leaves: " + leaves);
        	}
        	
        	if (option == 4)
        	{
        		System.out.println("The number of nodes with one child: " 
        				+ t.numOneChildNodes(t.root));
        		
        	}
        	
        	if (option == 5)
        	{
        		System.out.println("The number of nodes with two children: " 
        				+ t.numTwoChildrenNodes(t.root));
        		
        	}
        	
        	if (option == 6)
        	{
        		System.out.println("Print in level order: ");
        		
        		t.levelOrder(t.root);
        		
        		System.out.println();
       
        		
        	}
        	
        	if (option == 7)
        	{
        		System.out.println("Please enter k1: ");
        		int k1 = Integer.parseInt(buffering.readLine());
        		
        		System.out.println("Please enter k2: ");
        		int k2 = Integer.parseInt(buffering.readLine());
        		
        		System.out.println("Print what is between " + k1 + " and " + k2);
        		
        		t.printBetween(t.root, k1,k2);
        		
        		System.out.println();
        		
        		
        	}
        	
        	if (option == 8)
        	{
        		System.out.println("Bye bye for now!");
        	}
        	
        	else if (option > 8 || option < 1)
        	{
        		System.out.println("Please enter a valid input.");
        	}
        	
        } while (option != 8);
        
    }
}